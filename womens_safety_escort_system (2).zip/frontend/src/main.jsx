import React, {useEffect, useState} from "react";
import {createRoot} from "react-dom/client";
import "./style.css";

const API="http://localhost:8080/api/requests";

function App(){
  const [form,setForm]=useState({studentName:"",studentId:"",pickupLocation:"",destination:"",requestedTime:""});
  const [requests,setRequests]=useState([]);
  const [message,setMessage]=useState("");

  const load=()=>fetch(API).then(r=>r.json()).then(setRequests).catch(()=>{});
  useEffect(()=>{load()},[]);

  const submit=async e=>{
    e.preventDefault(); setMessage("");
    const res=await fetch(API,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)});
    if(res.ok){setMessage("Escort request submitted successfully.");setForm({studentName:"",studentId:"",pickupLocation:"",destination:"",requestedTime:""});load();}
    else setMessage("Please fill all required fields.");
  };

  return <div className="app">
    <header><div><h1>🛡️ Campus SafeWalk</h1><p>Women’s Safety Escort Request System</p></div><span className="badge">CAMPUS SAFETY</span></header>
    <main>
      <section className="hero"><h2>Request a Safe Escort</h2><p>Enter your current location, destination and requested time.</p></section>
      <section className="grid">
        <form className="card" onSubmit={submit}>
          <h3>📝 New Escort Request</h3>
          {["studentName","studentId","pickupLocation","destination","requestedTime"].map((k,i)=>
            <label key={k}>{k==="studentName"?"Student Name":k==="studentId"?"Student ID":k==="pickupLocation"?"Current / Pickup Location":k==="destination"?"Destination":"Requested Time"}
              <input required type={k==="requestedTime"?"time":"text"} value={form[k]} onChange={e=>setForm({...form,[k]:e.target.value})}/>
            </label>
          )}
          <button>Request Escort</button>
          {message && <div className="message">{message}</div>}
        </form>
        <section className="card">
          <h3>📍 My Requests</h3>
          {requests.length===0?<p className="muted">No requests yet.</p>:requests.map(r=>
            <div className="request" key={r.id}>
              <div><b>#{r.id} {r.pickupLocation} → {r.destination}</b><small>{r.studentName} • {r.requestedTime}</small></div>
              <span className={"status "+r.status.toLowerCase()}>{r.status}</span>
              <small>Escort: {r.escortName || "Not assigned"}</small>
            </div>
          )}
        </section>
      </section>
    </main>
  </div>
}
createRoot(document.getElementById("root")).render(<App/>);