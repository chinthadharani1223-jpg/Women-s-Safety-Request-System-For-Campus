package com.campus.safety.model;
import jakarta.persistence.*;
@Entity
public class EscortRequest {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 private String studentName, studentId, pickupLocation, destination, requestedTime, status, escortName;
 public Long getId(){return id;} public String getStudentName(){return studentName;} public void setStudentName(String v){studentName=v;}
 public String getStudentId(){return studentId;} public void setStudentId(String v){studentId=v;}
 public String getPickupLocation(){return pickupLocation;} public void setPickupLocation(String v){pickupLocation=v;}
 public String getDestination(){return destination;} public void setDestination(String v){destination=v;}
 public String getRequestedTime(){return requestedTime;} public void setRequestedTime(String v){requestedTime=v;}
 public String getStatus(){return status;} public void setStatus(String v){status=v;}
 public String getEscortName(){return escortName;} public void setEscortName(String v){escortName=v;}
}