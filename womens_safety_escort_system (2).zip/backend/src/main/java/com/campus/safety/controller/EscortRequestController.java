package com.campus.safety.controller;
import java.util.List;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import com.campus.safety.model.EscortRequest;
import com.campus.safety.service.EscortRequestService;
@RestController
@RequestMapping("/api/requests")
@CrossOrigin(origins="http://localhost:5173")
public class EscortRequestController {
 private final EscortRequestService service;
 public EscortRequestController(EscortRequestService service){this.service=service;}
 @GetMapping public List<EscortRequest> all(){return service.all();}
 @PostMapping public ResponseEntity<?> create(@RequestBody EscortRequest r){
  if(r.getStudentName()==null||r.getStudentName().isBlank()||r.getPickupLocation()==null||r.getPickupLocation().isBlank()||r.getDestination()==null||r.getDestination().isBlank()||r.getRequestedTime()==null||r.getRequestedTime().isBlank())
   return ResponseEntity.badRequest().body("Required fields are missing");
  return ResponseEntity.status(HttpStatus.CREATED).body(service.create(r));
 }
}