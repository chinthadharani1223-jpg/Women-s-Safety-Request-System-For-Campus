package com.campus.safety.service;
import java.util.List;
import org.springframework.stereotype.Service;
import com.campus.safety.model.EscortRequest;
import com.campus.safety.repository.EscortRequestRepository;
@Service
public class EscortRequestService {
 private final EscortRequestRepository repo;
 public EscortRequestService(EscortRequestRepository repo){this.repo=repo;}
 public List<EscortRequest> all(){return repo.findAll();}
 public EscortRequest create(EscortRequest r){r.setStatus("PENDING");r.setEscortName(null);return repo.save(r);}
}