package com.campus.safety;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class CampusSafetyApplication { public static void main(String[] args){SpringApplication.run(CampusSafetyApplication.class,args);} }