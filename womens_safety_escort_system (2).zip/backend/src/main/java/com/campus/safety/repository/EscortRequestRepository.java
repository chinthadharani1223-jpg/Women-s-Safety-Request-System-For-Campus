package com.campus.safety.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.campus.safety.model.EscortRequest;
public interface EscortRequestRepository extends JpaRepository<EscortRequest,Long>{}