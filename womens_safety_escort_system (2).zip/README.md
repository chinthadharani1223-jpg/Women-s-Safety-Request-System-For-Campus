# Women's Safety Escort Request System for Campus

Beginner-friendly React + Spring Boot starter project.

## Requirements
- Java 17+
- Maven
- Node.js 18+

## Run backend
cd backend
mvn spring-boot:run

## Run frontend
cd frontend
npm install
npm run dev

Open http://localhost:5173

The backend uses H2 for easy demo/testing. For the final hackathon version, replace H2 with MySQL/PostgreSQL as required by the problem statement.

## Main API
POST /api/requests
GET /api/requests
